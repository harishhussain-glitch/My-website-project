import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowUpRight,
  CalendarDays,
  Calculator,
  Check,
  Clock3,
  Compass,
  Copy,
  Globe2,
  Leaf,
  MessageCircle,
  Search,
  Sparkles,
  SunMedium,
  Telescope,
} from 'lucide-react';

type AnswerKind = 'idle' | 'loading' | 'answer' | 'unknown';

type Answer = {
  kind: AnswerKind;
  title: string;
  body: string;
  meta: string;
  icon: typeof Sparkles;
  tone: 'blue' | 'warm' | 'green' | 'violet';
};

type Token = number | '+' | '-' | '*' | '/' | '(' | ')';

const EXAMPLES = [
  { label: 'Say hello', query: 'hello' },
  { label: 'What is my name?', query: 'what is my name' },
  { label: 'Capital of Japan', query: 'what is the capital of japan' },
  { label: 'Try 18 × 7', query: '18 * 7' },
  { label: 'Why is the sky blue?', query: 'why is the sky blue' },
];

const facts = [
  {
    label: 'Earth',
    detail: 'Our home planet, third from the Sun.',
    icon: Globe2,
    tone: 'blue',
  },
  {
    label: 'Moon',
    detail: 'Earth’s natural satellite.',
    icon: Telescope,
    tone: 'violet',
  },
  {
    label: 'Sun',
    detail: 'The star at the heart of our system.',
    icon: SunMedium,
    tone: 'warm',
  },
] as const;

function tokenize(expression: string): Token[] | null {
  const tokens: Token[] = [];
  let index = 0;

  while (index < expression.length) {
    const char = expression[index];
    if (char === ' ') {
      index += 1;
      continue;
    }

    if (/[0-9.]/.test(char)) {
      const match = expression.slice(index).match(/^(?:\d+(?:\.\d*)?|\.\d+)/);
      if (!match) return null;
      tokens.push(Number(match[0]));
      index += match[0].length;
      continue;
    }

    if ('+-*/()'.includes(char)) {
      tokens.push(char as Exclude<Token, number>);
      index += 1;
      continue;
    }

    return null;
  }

  return tokens.length ? tokens : null;
}

function calculate(expression: string): number | null {
  const tokens = tokenize(expression);
  if (!tokens) return null;
  let position = 0;

  const parseExpression = (): number | null => {
    let value = parseTerm();
    while (value !== null && (tokens[position] === '+' || tokens[position] === '-')) {
      const operator = tokens[position];
      position += 1;
      const next = parseTerm();
      if (next === null) return null;
      value = operator === '+' ? value + next : value - next;
    }
    return value;
  };

  const parseTerm = (): number | null => {
    let value = parseFactor();
    while (value !== null && (tokens[position] === '*' || tokens[position] === '/')) {
      const operator = tokens[position];
      position += 1;
      const next = parseFactor();
      if (next === null || (operator === '/' && next === 0)) return null;
      value = operator === '*' ? value * next : value / next;
    }
    return value;
  };

  const parseFactor = (): number | null => {
    const token = tokens[position];
    if (token === '+') {
      position += 1;
      return parseFactor();
    }
    if (token === '-') {
      position += 1;
      const value = parseFactor();
      return value === null ? null : -value;
    }
    if (token === '(') {
      position += 1;
      const value = parseExpression();
      if (tokens[position] !== ')') return null;
      position += 1;
      return value;
    }
    if (typeof token === 'number') {
      position += 1;
      return token;
    }
    return null;
  };

  const result = parseExpression();
  return result !== null && position === tokens.length && Number.isFinite(result) ? result : null;
}

function formatNumber(value: number) {
  return Number.isInteger(value) ? value.toLocaleString() : value.toLocaleString(undefined, { maximumFractionDigits: 8 });
}

function nowLabel() {
  return new Intl.DateTimeFormat(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date());
}

function timeLabel() {
  return new Intl.DateTimeFormat(undefined, {
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
  }).format(new Date());
}

const CAPITAL_ANSWERS: Record<string, { country: string; capital: string; detail: string }> = {
  france: { country: 'France', capital: 'Paris', detail: 'Paris is the capital and largest city of France.' },
  japan: { country: 'Japan', capital: 'Tokyo', detail: 'Tokyo is the capital of Japan, on the island of Honshu.' },
  uae: { country: 'the United Arab Emirates', capital: 'Abu Dhabi', detail: 'Abu Dhabi is the capital of the United Arab Emirates.' },
  'united arab emirates': { country: 'the United Arab Emirates', capital: 'Abu Dhabi', detail: 'Abu Dhabi is the capital of the United Arab Emirates.' },
  india: { country: 'India', capital: 'New Delhi', detail: 'New Delhi is the capital of India.' },
  china: { country: 'China', capital: 'Beijing', detail: 'Beijing is the capital of China.' },
  australia: { country: 'Australia', capital: 'Canberra', detail: 'Canberra is the capital of Australia.' },
  usa: { country: 'the United States', capital: 'Washington, D.C.', detail: 'Washington, D.C. is the capital of the United States.' },
  'united states': { country: 'the United States', capital: 'Washington, D.C.', detail: 'Washington, D.C. is the capital of the United States.' },
  america: { country: 'the United States', capital: 'Washington, D.C.', detail: 'Washington, D.C. is the capital of the United States.' },
  'saudi arabia': { country: 'Saudi Arabia', capital: 'Riyadh', detail: 'Riyadh is the capital of Saudi Arabia.' },
  uk: { country: 'the United Kingdom', capital: 'London', detail: 'London is the capital of the United Kingdom.' },
  'united kingdom': { country: 'the United Kingdom', capital: 'London', detail: 'London is the capital of the United Kingdom.' },
};

function answerFor(query: string): Omit<Answer, 'kind'> {
  const normalized = query.trim().toLowerCase().replace(/[?!.,]/g, '').replace(/\s+/g, ' ');
  const arithmeticCandidate = normalized
    .replace(/^(what is|calculate|solve|answer)\s+/i, '')
    .replace(/[×÷]/g, (symbol) => (symbol === '×' ? '*' : '/'));
  const isArithmetic = /^[\d\s()+\-*/.]+$/.test(arithmeticCandidate) && /\d/.test(arithmeticCandidate) && /[+\-*/]/.test(arithmeticCandidate);

  if (isArithmetic) {
    const result = calculate(arithmeticCandidate);
    if (result !== null) {
      return {
        title: formatNumber(result),
        body: `${query.trim()} is a safe little calculation. Try another expression whenever you like.`,
        meta: 'CALCULATOR',
        icon: Calculator,
        tone: 'blue',
      };
    }
  }

  if (/^(hi|hey|hello|salam|assalamualaikum|good morning|good evening)\b/.test(normalized)) {
    return {
      title: 'Hello, friend.',
      body: 'I’m Ayaan’s small web companion. Ask me something simple and I’ll do my best to point you in the right direction.',
      meta: 'A WARM WELCOME',
      icon: MessageCircle,
      tone: 'warm',
    };
  }

  if (/what('?s| is) (your|my) name|who are you|who am i|your name|my name/.test(normalized)) {
    return {
      title: 'You’re visiting Ayaan’s Web.',
      body: 'And I’m the friendly little guide made to answer a few useful things without making a fuss.',
      meta: 'ABOUT THIS PLACE',
      icon: Compass,
      tone: 'blue',
    };
  }

  if (/what can you do|what do you know|how does this work|help me/.test(normalized)) {
    return {
      title: 'Ask me anything simple.',
      body: 'I can greet you, tell you the date or time, solve safe maths, share country capitals, and explain a few science and space facts.',
      meta: 'HOW TO USE AYAAN’S WEB',
      icon: Sparkles,
      tone: 'blue',
    };
  }

  if (/^(thanks|thank you|thx|thank)/.test(normalized)) {
    return {
      title: 'You’re welcome.',
      body: 'I’m always happy to help with another question.',
      meta: 'KIND WORDS',
      icon: MessageCircle,
      tone: 'warm',
    };
  }

  if (/who made you|who created you|who built you/.test(normalized)) {
    return {
      title: 'Ayaan made this web.',
      body: 'It is a small browser project made to be friendly, useful, and easy to explore.',
      meta: 'A LITTLE ORIGIN STORY',
      icon: Sparkles,
      tone: 'violet',
    };
  }

  if (/date|today|what day/.test(normalized)) {
    return {
      title: nowLabel(),
      body: 'That’s today, according to the clock on this device.',
      meta: 'CURRENT DATE',
      icon: CalendarDays,
      tone: 'green',
    };
  }

  if (/time|clock|what hour/.test(normalized)) {
    return {
      title: timeLabel(),
      body: 'That’s the current local time on this device.',
      meta: 'CURRENT TIME',
      icon: Clock3,
      tone: 'violet',
    };
  }

  const asksForCapital = /capital|city is|city of/.test(normalized);
  const capitalEntry = Object.entries(CAPITAL_ANSWERS).find(([country]) => normalized.includes(country));
  if (asksForCapital && capitalEntry) {
    const [, answer] = capitalEntry;
    return {
      title: answer.capital,
      body: answer.detail,
      meta: answer.country.toUpperCase(),
      icon: Globe2,
      tone: answer.country === 'Japan' ? 'warm' : answer.country === 'the United Arab Emirates' ? 'green' : 'blue',
    };
  }

  if (/what is ai|what does ai mean|artificial intelligence/.test(normalized)) {
    return {
      title: 'AI means artificial intelligence.',
      body: 'It is technology that helps computers find patterns, understand language, and make useful predictions or answers.',
      meta: 'A QUICK EXPLANATION',
      icon: Sparkles,
      tone: 'violet',
    };
  }

  if (/why is the sky blue|why does the sky look blue/.test(normalized)) {
    return {
      title: 'Because of sunlight and air.',
      body: 'Sunlight has many colors. Earth’s air spreads the blue part of the light around the sky more than the other colors, so we see blue.',
      meta: 'SCIENCE IN A FEW WORDS',
      icon: Globe2,
      tone: 'blue',
    };
  }

  if (/how many planets|planets in (the )?solar system|largest planet/.test(normalized)) {
    return {
      title: 'There are eight planets.',
      body: 'They orbit the Sun: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune. Jupiter is the largest.',
      meta: 'OUR SOLAR SYSTEM',
      icon: Telescope,
      tone: 'violet',
    };
  }

  if (/what is water|water made of|formula for water/.test(normalized)) {
    return {
      title: 'Water is H₂O.',
      body: 'That means each water molecule has two hydrogen atoms and one oxygen atom.',
      meta: 'A QUICK SCIENCE FACT',
      icon: Leaf,
      tone: 'blue',
    };
  }

  if (/what is gravity|how does gravity work/.test(normalized)) {
    return {
      title: 'Gravity is a pulling force.',
      body: 'It pulls objects toward one another. Earth’s gravity is what keeps us on the ground and the Moon near Earth.',
      meta: 'A QUICK SCIENCE FACT',
      icon: Globe2,
      tone: 'green',
    };
  }

  if (/\bearth\b/.test(normalized)) {
    return {
      title: 'Earth',
      body: 'Earth is the third planet from the Sun and the only place we currently know to hold life.',
      meta: 'A QUICK FACT',
      icon: Globe2,
      tone: 'blue',
    };
  }

  if (/\bmoon\b/.test(normalized)) {
    return {
      title: 'Moon',
      body: 'The Moon is Earth’s natural satellite. Its gentle pull helps shape our ocean tides.',
      meta: 'A QUICK FACT',
      icon: Telescope,
      tone: 'violet',
    };
  }

  if (/\bsun\b/.test(normalized)) {
    return {
      title: 'Sun',
      body: 'The Sun is the star at the center of our solar system, keeping the planets in orbit with its gravity.',
      meta: 'A QUICK FACT',
      icon: SunMedium,
      tone: 'warm',
    };
  }

  return {
    title: 'Let’s try a simpler question.',
    body: 'I’m still learning that one. Try “Why is the sky blue?”, “What is AI?”, “Capital of India”, or “18 × 7”.',
    meta: 'TRY ONE OF THESE',
    icon: Sparkles,
    tone: 'violet',
  };
}

function ToneIcon({ icon: Icon, tone }: { icon: Answer['icon']; tone: Answer['tone'] }) {
  const toneClasses = {
    blue: 'bg-[#d9effb] text-[#1e6c9b]',
    warm: 'bg-[#ffead5] text-[#b76728]',
    green: 'bg-[#dff1e9] text-[#28755d]',
    violet: 'bg-[#e9e4f7] text-[#65518f]',
  };
  return (
    <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${toneClasses[tone]}`}>
      <Icon size={20} strokeWidth={1.8} />
    </span>
  );
}

function AnswerPanel({ answer }: { answer: Answer }) {
  if (answer.kind === 'idle') {
    return (
      <div className="flex min-h-[190px] flex-col justify-between p-6 sm:p-7" data-testid="state-empty">
        <div className="flex items-start justify-between">
          <span className="meta-mono text-[#6e8495]">READY WHEN YOU ARE</span>
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[#e3f2f9] text-[#287aa6]">
            <Sparkles size={19} strokeWidth={1.8} />
          </span>
        </div>
        <div>
          <p className="mb-1 font-serif text-2xl font-semibold tracking-[-0.04em] text-[#24394c]">A blank page, in a good way.</p>
          <p className="max-w-sm text-sm leading-6 text-[#6e7f8b]">Type a question above, or borrow one of the prompts below to get started.</p>
        </div>
      </div>
    );
  }

  if (answer.kind === 'loading') {
    return (
      <div className="min-h-[190px] animate-pulse p-6 sm:p-7" data-testid="state-loading" aria-live="polite">
        <div className="mb-7 h-3 w-28 rounded-full bg-[#dceaf0]" />
        <div className="mb-3 h-9 w-3/4 rounded-lg bg-[#e2eef3]" />
        <div className="h-4 w-full rounded-full bg-[#e7f0f3]" />
        <div className="mt-2 h-4 w-4/5 rounded-full bg-[#e7f0f3]" />
      </div>
    );
  }

  return (
    <div className="answer-card min-h-[190px] p-6 sm:p-7" data-testid={`state-${answer.kind}`} aria-live="polite">
      <div className="mb-7 flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <ToneIcon icon={answer.icon} tone={answer.tone} />
          <span className="meta-mono text-[#6e8495]">{answer.meta}</span>
        </div>
        {answer.kind === 'unknown' ? (
          <span className="rounded-full bg-[#f3eee7] px-3 py-1 text-xs font-semibold text-[#8c7057]">still learning</span>
        ) : (
          <Check size={18} className="text-[#38876e]" strokeWidth={2.2} />
        )}
      </div>
      <h2 className="mb-2 font-serif text-[clamp(1.85rem,4vw,2.6rem)] font-semibold leading-none tracking-[-0.05em] text-[#24394c]" data-testid="text-answer-title">
        {answer.title}
      </h2>
      <p className="max-w-xl text-sm leading-6 text-[#6e7f8b]" data-testid="text-answer-body">{answer.body}</p>
    </div>
  );
}

function Home() {
  const [query, setQuery] = useState('');
  const [submittedQuery, setSubmittedQuery] = useState('');
  const [answer, setAnswer] = useState<Answer>({ kind: 'idle', title: '', body: '', meta: '', icon: Sparkles, tone: 'blue' });
  const [copied, setCopied] = useState(false);
  const [time, setTime] = useState(timeLabel);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = window.setInterval(() => setTime(timeLabel()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const answerText = useMemo(() => answer.kind === 'answer' || answer.kind === 'unknown' ? `${answer.title} ${answer.body}` : '', [answer]);

  const submit = (nextQuery = query) => {
    const cleanQuery = nextQuery.trim();
    if (!cleanQuery) {
      inputRef.current?.focus();
      return;
    }
    setQuery(cleanQuery);
    setSubmittedQuery(cleanQuery);
    setCopied(false);
    setAnswer({ kind: 'loading', title: '', body: '', meta: '', icon: Sparkles, tone: 'blue' });
    window.setTimeout(() => {
      const result = answerFor(cleanQuery);
      setAnswer({ ...result, kind: result.meta === 'TRY ONE OF THESE' ? 'unknown' : 'answer' });
    }, 220);
  };

  const copyAnswer = async () => {
    if (!answerText || !navigator.clipboard) return;
    await navigator.clipboard.writeText(answerText);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
    <main className="app-shell" data-testid="page-home">
      <div className="page-wrap">
        <header className="flex items-center justify-between" data-testid="site-header">
          <div className="flex items-center gap-3">
            <span className="brand-mark" aria-hidden="true"><Sparkles size={21} strokeWidth={1.8} /></span>
            <div>
              <p className="font-serif text-lg font-bold tracking-[-0.04em] text-[#20384d]">Ayaan’s Web</p>
              <p className="meta-mono hidden text-[#77909f] sm:block">a tiny place for good questions</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-[#c7dce6] bg-[#edf7fb]/70 px-3 py-2 text-xs font-semibold text-[#4d7185]" data-testid="status-online">
            <span className="h-2 w-2 rounded-full bg-[#59a98a] shadow-[0_0_0_3px_rgba(89,169,138,0.13)]" />
            <span>open and listening</span>
          </div>
        </header>

        <section className="hero-layout">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#c7dce6] bg-[#edf7fb]/75 px-3 py-1.5 text-xs font-semibold text-[#4d7185]">
              <span className="meta-mono text-[#6e9db5]">01</span>
              <span>ask without overthinking it</span>
            </div>
            <h1 className="hero-title">A little web<br /><em>with answers.</em></h1>
            <p className="mt-7 max-w-md text-[1.05rem] leading-7 text-[#607789]">
              Ayaan’s Web is a friendly corner for quick facts, small calculations, and the questions that pop into your head.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-5 text-xs font-semibold text-[#718797]">
              <span className="flex items-center gap-2"><Calculator size={15} className="text-[#287aa6]" /> safe calculations</span>
              <span className="flex items-center gap-2"><Clock3 size={15} className="text-[#b76728]" /> right now, right here</span>
            </div>
          </div>

          <div className="search-card overflow-hidden">
            <form
              className="border-b soft-line p-4 sm:p-5"
              onSubmit={(event) => {
                event.preventDefault();
                submit();
              }}
              data-testid="form-question"
            >
              <label htmlFor="question" className="meta-mono mb-3 block text-[#6e8495]">YOUR QUESTION</label>
              <div className="flex items-center gap-3 rounded-2xl border border-[#c9dfe9] bg-[#f7fcfd] p-2 pl-4 transition-colors focus-within:border-[#5796b4] focus-within:ring-4 focus-within:ring-[#86bed5]/20">
                <Search size={19} className="shrink-0 text-[#7aa6b9]" strokeWidth={1.8} />
                <input
                  ref={inputRef}
                  id="question"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Ask me something..."
                  className="min-w-0 flex-1 bg-transparent py-2 text-sm text-[#24394c] outline-none placeholder:text-[#8ca2ae]"
                  data-testid="input-question"
                  autoComplete="off"
                />
                <button
                  type="submit"
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#286f9e] text-[#edf8fb] transition-transform hover:bg-[#205d86] active:scale-95 disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={!query.trim() || answer.kind === 'loading'}
                  aria-label="Submit question"
                  data-testid="button-submit-question"
                >
                  <ArrowUpRight size={19} strokeWidth={2} />
                </button>
              </div>
              <div className="mt-3 flex items-center justify-between px-1">
                <span className="text-xs text-[#8ba0aa]">Press Enter to ask</span>
                <span className="meta-mono text-[#8ba0aa]">local answers</span>
              </div>
            </form>
            <AnswerPanel answer={answer} />
            {answerText && (
              <div className="flex items-center justify-between border-t soft-line px-6 py-3 sm:px-7" data-testid="answer-actions">
                <span className="truncate pr-4 text-xs text-[#8ba0aa]">Asked: “{submittedQuery}”</span>
                <button
                  type="button"
                  onClick={copyAnswer}
                  className="flex shrink-0 items-center gap-1.5 text-xs font-semibold text-[#47768d] transition-colors hover:text-[#205d86]"
                  data-testid="button-copy-answer"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  {copied ? 'Copied' : 'Copy answer'}
                </button>
              </div>
            )}
          </div>
        </section>

        <section className="mx-auto mt-16 max-w-[1080px]" aria-labelledby="examples-title">
          <div className="mb-4 flex items-end justify-between gap-4">
            <div>
              <span className="meta-mono text-[#77909f]">START HERE</span>
              <h2 id="examples-title" className="mt-1 font-serif text-2xl font-semibold tracking-[-0.04em] text-[#2d4354]">Good questions, ready to go.</h2>
            </div>
            <span className="hidden text-xs text-[#8498a3] sm:block">{EXAMPLES.length} ways in</span>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {EXAMPLES.map((example) => (
              <button
                key={example.query}
                type="button"
                onClick={() => submit(example.query)}
                className="question-chip px-4 py-2.5 text-sm font-semibold"
                data-testid={`button-example-${example.query.replace(/[^a-z0-9]+/g, '-')}`}
              >
                {example.label}
              </button>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-16 max-w-[1080px] border-t soft-line pt-7" aria-labelledby="facts-title">
          <div className="grid gap-8 md:grid-cols-[0.75fr_1.25fr] md:items-start">
            <div>
              <span className="meta-mono text-[#77909f]">A FEW CONSTANTS</span>
              <h2 id="facts-title" className="mt-1 max-w-xs font-serif text-3xl font-semibold leading-tight tracking-[-0.05em] text-[#2d4354]">The big things are worth remembering.</h2>
              <p className="mt-3 max-w-xs text-sm leading-6 text-[#718592]">Ask about Earth, Moon, or Sun whenever you want a quick reminder.</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {facts.map((fact) => {
                const Icon = fact.icon;
                const toneClass = fact.tone === 'warm' ? 'bg-[#fff0e2] text-[#b76728]' : fact.tone === 'violet' ? 'bg-[#eee9f7] text-[#65518f]' : 'bg-[#e1f2fa] text-[#287aa6]';
                return (
                  <button
                    type="button"
                    key={fact.label}
                    onClick={() => submit(`tell me about ${fact.label}`)}
                    className="lift rounded-2xl border border-[#cbdfe7] bg-[#f5fafb]/65 p-4 text-left"
                    data-testid={`button-fact-${fact.label.toLowerCase()}`}
                  >
                    <span className={`mb-7 grid h-9 w-9 place-items-center rounded-xl ${toneClass}`}><Icon size={17} strokeWidth={1.8} /></span>
                    <span className="block font-serif text-xl font-semibold tracking-[-0.04em] text-[#2d4354]">{fact.label}</span>
                    <span className="mt-1 block text-xs leading-5 text-[#718592]">{fact.detail}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        <footer className="mx-auto mt-14 flex max-w-[1080px] flex-col justify-between gap-3 border-t soft-line pt-5 text-xs text-[#8296a1] sm:flex-row">
          <span>Made for curious moments.</span>
          <span className="flex items-center gap-2"><span className="meta-mono">{time}</span><span className="h-1 w-1 rounded-full bg-[#a8c1cc]" />runs right in your browser</span>
        </footer>
      </div>
    </main>
  );
}

export default Home;